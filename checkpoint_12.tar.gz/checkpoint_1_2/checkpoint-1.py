import subprocess
import os
import time

def execute():
    try:
        timestamp = int(time.time())
        # Tuesday, 3 November 2026 at 23:59:59 UTC+05:30
        if timestamp > 1793730599:
            print("Patch Expired")
            exit()
            
        # Set HADOOP_USER_NAME from the specified file
        with open('/DNIF/DL/csltuconfig/username', 'r') as username_file:
            hadoop_user_name = username_file.read().strip()
            if hadoop_user_name:
                environ = dict(os.environ)
                environ['HADOOP_USER_NAME'] = hadoop_user_name

        # Change the working directory to /opt/hadoop-3.2.3/bin
        os.chdir('/opt/hadoop/bin')

        # Define Hadoop commands and corresponding service names
        hadoop_commands = [
            (['./hdfs', 'fsck', '/', '-files', '-blocks', '-locations'], 'HDFS fsck'),
            (['./hdfs', 'dfsadmin', '-report'], 'DFS Admin report'),
            (['./hdfs', 'dfsadmin', '-safemode', 'enter'], 'Enter safemode'),
            (['./hdfs', 'dfsadmin', '-saveNamespace'], 'Save Namespace'),
            (['./hdfs', 'dfsadmin', '-safemode', 'leave'], 'Leave safemode')
        ]

        # Function to run a command and print a custom completion message
        def run_command(command, service_name, suppress_output=False):
            if not suppress_output:
                print(f"Running {service_name}...")
            subprocess.run(command, env=environ, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            print(f"{service_name} completed.")

        # Run HDFS commands using subprocess and print custom completion messages
        for i, (cmd, service) in enumerate(hadoop_commands):
            suppress_output = i < 2  # Suppress output for the first two commands
            run_command(cmd, service, suppress_output)

        print("HDFS maintenance tasks have been completed.")
    except Exception as e:
        print("Error in Applying Patch")
        print(e)

if __name__ == "__main__":
    execute()
