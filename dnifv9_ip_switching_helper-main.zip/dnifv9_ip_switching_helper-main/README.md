# DNIFV9_IP_Switching_helper

A Custom script to help switching the cluster IPs without getting into redeployment exercise.

![ip_switch_diagram](./pic/IP-Seg-Change.jpg)

### Project Structure -

```
.
├── comp_scripts
│   ├── AD
│   │   ├── ad_ip.yaml
│   │   └── ip_changes_ad.py
│   ├── CO
│   │   ├── co_ip.yaml
│   │   └── ip_changes_co.py
│   ├── DN
│   │   ├── dm_ip.yaml
│   │   └── ip_changes_dn.py
│   └── LC
│       └── ip_changes_lc.py
├── ip_key_reader.py
├── key_helper.py
├── pic
│   └── IP-Seg-Change.jpg
└── README.md
```
 

The project consists of six directories and eleven files.  

Each folder within comp_scripts corresponds to a DNIF component and contains a `.yaml` file along with an `ip_change_<Component>.py` Python script.  
These scripts facilitate updating the newly assigned IP address for the respective component. 
> ~~Each script must be executed individually inside the container of the corresponding DNIF component.~~

Additionally, there is a crucial script named `key_helper.py` located in the root (`./`) directory. This script must be executed on the CORE/DN-MASTER. It retrieves the existing IP keys configured for various services on the CORE and stores them in a `.json` file. After retrieval, the old IP must be manually replaced with the new IP (either manually or using `sed`).  

Once the JSON file is validated, the same script, when run in PUT mode, will apply the new IP addresses to their respective locations within the DNIF CO services.


## Syntax (key_helper.py) -

**THIS SCRIPT MUST BE EXECUTED FROM WITHIN THE CORE CONTAINER.**

    ```
    #python3 key_helper.py <[co|dn|ad|compId]> <[get|put]>
    ```
The script is executed using python3, followed by the script name and appropriate options.

**Options:**

 - **co** – Retrieves IP keys related to CORE services.  
 - **dn** – Retrieves IP keys related to DATA-NODE services.  
 - **ad** – Retrieves IP keys related to ADAPTOR services.  
 - **compId** – Retrieves IP keys related to compId.json.  

**Modes**:

  - **get** – Reads the values and saves them in a `.json` file.  
  - **put** – Reads values from the `.json` file and updates the corresponding keys as defined.  
  
It is recommended to first execute `get` to retrieve the latest configuration for the components, make the necessary changes, and then execute `put` to update the keys accordingly.

> The script also creates a backup file [<comp>_backup_YYYYMMDD_hhmmss.tar.gz] of the original key configuration while generating a template `.json` file for modifications and applying changes using the PUT operation.

**Example**:

Executing the script to retrieve the compId configuration template for updating to a new IP:

```
## Inside CORE Container @path[pwd] => `/var/tmp/dnifv9_ip_switching_helper/`

root@CO:/var/tmp/dnifv9_ip_switching_helper# python3 key_helper.py compId get
Backup created: ./compId_backup_20250312_064627.tar.gz

root@CO:/var/tmp/dnifv9_ip_switching_helper# ls
README.md  compId.json  compId_backup_20250312_064627.tar.gz  comp_scripts  ip_key_reader.py  key_helper.py  pic

root@CO:/var/tmp/dnifv9_ip_switching_helper# tar -tf compId_backup_20250312_064627.tar.gz 
compId.json

```



