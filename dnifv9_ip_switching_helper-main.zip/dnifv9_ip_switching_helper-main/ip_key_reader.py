import json
import ast
import sys
import os
import warnings

## Suppressing urllib warning on execution
warnings.filterwarnings("ignore")

## Setting up environment and import path
os.environ['WORKDIR'] = '/dnif'
sys.path.append('/usr/src/nm/core-v9')

from config_loader import etcd_conf
from core_utils.etcd_helper.etcd_helper import ConfigManager
etcd = ConfigManager(host=etcd_conf.ETCD_HOST, port=etcd_conf.ETCD_PORT)

def get_comp_ids(comp):
    prefix = '/cfg/' + comp
    m_entries = etcd.get_prefix(prefix)
    filter_entries = {}
    for entry in m_entries:
        key = entry.key.decode('utf-8')
        value = entry.value.decode('utf-8')

        if key.endswith('/system'):
            b = ast.literal_eval(value)
            jvalue = json.dumps(b)
            res_json = json.loads(jvalue)
            filter_entries[key] = res_json
    return(filter_entries)

def get_ip_list(comp):
    prefix = '/cfg/' + comp
    m_entries = etcd.get_prefix(prefix)
    filter_entries = {}
    for entry in m_entries:
        key = entry.key.decode('utf-8')
        value = entry.value.decode('utf-8')

        if key.endswith('/ip_list'):
            b = ast.literal_eval(value)
            jvalue = json.dumps(b)
            res_json = json.loads(jvalue)
            filter_entries[key] = res_json
    return(filter_entries)

def print_val(result, comp):
    for key, value in result.items():
        #print(f"Key ({comp}): {key}\nValue ({comp}): {value['comp_id']} IP_Addr: {value['localIPv4Address']}\n")
        print(f"Key ({comp}): {key}\nValue ({comp}): {value}\n")


#res = get_comp_ids('dn')
res = get_ip_list('dn')
print_val(res,'dn')
#res = get_comp_ids('ad')
res = get_ip_list('ad')
print_val(res,'ad')
#res = get_comp_ids('co')
res = get_ip_list('co')
print_val(res,'co')





