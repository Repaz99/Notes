import yaml
import json

## Pre-defined Paths :
config_file = './ad_ip.yaml'
docker_conf_path = '/DNIF/AD/docker-compose.yaml'
sheepDog_conf_path = '/DNIF/AD/csltuconfig/Sheepdog.yml'

## helper functions :

def read_yaml(file_path):
    with open(file_path, 'r') as file:
        data = yaml.safe_load(file)
    return data

def write_yaml(file_path, data):
    with open(file_path, 'w') as file:
        yaml.safe_dump(data, file)

## Read Change :

Ch_data = read_yaml(config_file)
CoreIP = Ch_data['AD']['Core-IP']
AD_Local_host_IP = Ch_data['AD']['AD-host-IP']
#print(f'{CoreIP}   {AD_Local_host_IP}')

## change in docker-compose.yaml
dc_conf = read_yaml(docker_conf_path)
envmt_value = dc_conf['services']['adapter']['environment']
for i, env_var in enumerate(envmt_value):
    if env_var.startswith('CORE_IP='):
        envmt_value[i]=f'CORE_IP={CoreIP}'
        print(envmt_value[i])
        
    elif env_var.startswith('HOST_IP='):
        envmt_value[i]=f'HOST_IP={AD_Local_host_IP}'
        print(envmt_value[i])
        
    else:
        print(f"[+] {envmt_value[i]} Key NOT FOUND...")

print("-" * 50)
print ("docker-compose.yaml....")
print(json.dumps(dc_conf, indent=4))
#write_yaml(docker_conf_path, dc_conf)

## change in sheepDog.yml

shdg = read_yaml(sheepDog_conf_path)
shdg['Sheepdog']['primary-server']['host'] = CoreIP
print("-" * 50)
print ("Sheepdog.yml....")
print(json.dumps(shdg['Sheepdog']['primary-server'], indent=4))
write_yaml(sheepDog_conf_path, shdg)