### AD (Adeptor Support script `ip_change_ad.py`) 
AD IP change support script been created to setup the New-IP changes on Adeptor component. The helper script contains two components, a configuration file to provide new-IP input and a python script `ip_change_ad.py`.

> Note: To run/configure this there is no significence of OLD-IP. So the IPs you configure is the one you want to change to.

**ad_ip.yaml**
```
AD:
  AD-host-IP: 172.16.xx.yyy
  Core-IP: 172.16.xx.zzz
```
Here,
  AD-host-IP - is a New-IP you want to configure for ADEPTOR
  Core-IP - is a New-IP of CORE.

Once the IPs are properly defined in YAML file. You can run `ip_change_ad.py` script to make changes against the IP keys in Adeptor.
The script make changes in :

| Sr.No. | Config-Path |
|:---:|:---|
|<td colspan="2" align="center">CORE Configs</td>|
|1|/co_ip.yaml|
|2|/DNIF/docker-compose.yaml|
|3|/DNIF/CO/csltuconfig/etcd.yml|
|4|/DNIF/CO/csltuconfig/redis.yml|
|5|/DNIF/CO/csltuconfig/SHEEPDOG.yml|
|<td colspan="2" align="center">DATA-NODE Configs</td>|
|6|/DNIF/DL/csltuconfig/etcd.yml|
|7|/DNIF/DL/csltuconfig/redis.yml|
|8|/opt/hadoop/etc/hadoop/core-site.xml|
