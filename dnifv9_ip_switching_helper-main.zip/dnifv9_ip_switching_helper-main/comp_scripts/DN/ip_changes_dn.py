import yaml
import json
import re
import xml.etree.ElementTree as ET

## SUDO (Admin) user is required to run this script.

## Pre-defined Paths :

config_file = './dn_ip.yaml'

docker_compose_file_path = '/DNIF/DL/docker-compose.yaml'
dl_etcd_file_path = '/DNIF/DL/csltuconfig/etcd.yml'
dl_redis_file_path = '/DNIF/DL/csltuconfig/redis.yml'
qs_spk_env_path = '/DNIF/DL/query_server/conf/spark-env.sh'
qs_core_site = '/DNIF/DL/query_server/conf/core-site.xml'
cr_spk_env_path = '/DNIF/DL/correlation_server/conf/spark-env.sh'
cr_core_site = '/DNIF/DL/correlation_server/conf/core-site.xml'
rs_spk_env_path = '/DNIF/DL/report_server/conf/spark-env.sh'
rs_core_site = '/DNIF/DL/report_server/conf/core-site.xml'
etc_hadoop_core_site = '/opt/hadoop/etc/hadoop/core-site.xml'
spark_core_site = '/opt/spark/conf/core-site.xml'
opt_spk_env_path = '/opt/spark/conf/spark-env.sh'



## helper functions :

def read_yaml(file_path):
    with open(file_path, 'r') as file:
        data = yaml.safe_load(file)
    return data

def write_yaml(file_path, data):
    with open(file_path, 'w') as file:
        yaml.safe_dump(data, file)

def replace_ip_in_sh(file_path, var_name, new_ip):
    with open(file_path, 'r') as file :
        content = file.read()
    
    pattern = rf'export {var_name}=\d{{1,3}}\.\d{{1,3}}\.\d{{1,3}}\.\d{{1,3}}'
    replacement = f'export {var_name}={new_ip}'
    content = re.sub(pattern, replacement, content)

    #with open(file_path, 'w') as file:
    #    file.write(content)

def update_fs_default_name(file_path, new_value):
    tree = ET.parse(file_path)
    root = tree.getroot()
    for property in root.findall('property'):
        name = property.find('name').text
        if name == 'fs.default.name':
            property.find('value').text = new_value
            break

    #tree.write(file_path, encoding="utf-8", xml_declaration=True)



## Read Change :

Ch_data = read_yaml(config_file)
CoreIP = Ch_data['DN']['Core-IP']
dn_local_host_IP = Ch_data['DN']['DN-local-host-IP']

## /DNIF/docker-compose changes

print('-' * 25 + "docker-compose.yaml (Core-IP)" + "-" * 25)
dc_conf = read_yaml(docker_compose_file_path)
envmt_value_dn = dc_conf['services']['datanode']['environment']
for i, env_var in enumerate(envmt_value_dn):
    if env_var.startswith('CORE_IP='):
        envmt_value_dn[i]=f'CORE_IP={CoreIP}'
        print(envmt_value_dn[i])        
    else:
        print(f"[+] {envmt_value_dn[i]} Key NOT FOUND...")
#write_yaml(docker_compose_file_path, dc_conf)
print('-' * 50)


##------------- /DL/csltuconfig/etcd.yml --------
print('-' * 25 + "Changing DL/etcd.yml (Core-IP)" + '-' * 25)

dl_etc_cnf = read_yaml(dl_etcd_file_path)
dl_etc_cnf['etcd']['host'] = CoreIP
print(f"host = {dl_etc_cnf['etcd']['host']}")
#write_yaml(dl_etcd_file_path, etc_cnf)

##------------ /DL/csltuconfig/redis.yml -----------

print('-' * 25 + "Changing DL/redis.yml (DataNode-IP)" + '-' * 25)

dl_rds_cnf = read_yaml(dl_redis_file_path)
dl_rds_cnf['redis']['host'] = dn_local_host_IP
print(f"host = {dl_rds_cnf['redis']['host']}")
#write_yaml(dl_redis_file_path, rds_cnf)

##--------------- spark-env.sh (DataNode-IP)

print('-' * 25 + "query_server/conf/spark-env.sh (DataNode-IP)" + '-' * 25)

replace_ip_in_sh(qs_spk_env_path, 'SPARK_MASTER_HOST', dn_local_host_IP)
replace_ip_in_sh(qs_spk_env_path, 'SPARK_MASTER_IP', dn_local_host_IP)
replace_ip_in_sh(qs_spk_env_path, 'SPARK_LOCAL_IP', dn_local_host_IP)
print(f"SPARK_MASTER_HOST | SPARK_MASTER_IP |SPARK_LOCAL_IP is updated with DataNode-IP {dn_local_host_IP} in file - \n [+] {qs_spk_env_path}")

replace_ip_in_sh(cr_spk_env_path, 'SPARK_MASTER_HOST', dn_local_host_IP)
replace_ip_in_sh(cr_spk_env_path, 'SPARK_MASTER_IP', dn_local_host_IP)
replace_ip_in_sh(cr_spk_env_path, 'SPARK_LOCAL_IP', dn_local_host_IP)
print(f" [+] {cr_spk_env_path}")

replace_ip_in_sh(rs_spk_env_path, 'SPARK_MASTER_HOST', dn_local_host_IP)
replace_ip_in_sh(rs_spk_env_path, 'SPARK_MASTER_IP', dn_local_host_IP)
replace_ip_in_sh(rs_spk_env_path, 'SPARK_LOCAL_IP', dn_local_host_IP)
print(f" [+] {rs_spk_env_path}")

replace_ip_in_sh(opt_spk_env_path, 'SPARK_MASTER_HOST', dn_local_host_IP)
replace_ip_in_sh(opt_spk_env_path, 'SPARK_MASTER_IP', dn_local_host_IP)
replace_ip_in_sh(opt_spk_env_path, 'SPARK_LOCAL_IP', dn_local_host_IP)
print(f" [+] {opt_spk_env_path}")


##------------ [query_server|corelation_server|report_server]/conf/core-site.xml (Core-IP)

print('-' * 5 + "[query_server_core-site|corelation_server_core-site|report_server_core-site|etc_hadoop_core-site|opt_spark_core-site] with (Core-IP)" + '-' * 2)

fs_def_name = f"hdfs://{CoreIP}:9000/"
update_fs_default_name(qs_core_site, fs_def_name)
print(f"XML ---  <name>fs.default.name</name> ....Set to -\n File: {qs_core_site} <== Value: {fs_def_name}")
update_fs_default_name(cr_core_site, fs_def_name)
print(f" File: {cr_core_site} <== Value: {fs_def_name}")
update_fs_default_name(rs_core_site, fs_def_name)
print(f" File: {rs_core_site} <== Value: {fs_def_name}")
update_fs_default_name(etc_hadoop_core_site, fs_def_name)
print(f" File: {etc_hadoop_core_site} <== Value: {fs_def_name}")
## root access required to edit this next path ========
update_fs_default_name(spark_core_site, fs_def_name)
print(f" File: {spark_core_site} <== Value: {fs_def_name}")

#pattern = r'spark://\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}'