import yaml
import json
import xml.etree.ElementTree as ET

## Pre-defined Paths :

config_file = './co_ip.yaml'
docker_compose_file_path = '/DNIF/docker-compose.yaml'
etcd_file_path = '/DNIF/CO/csltuconfig/etcd.yml'
redis_file_path = '/DNIF/CO/csltuconfig/redis.yml'
sheepDog_file_path = '/DNIF/CO/csltuconfig/SHEEPDOG.yml'

dl_etcd_file_path = '/DNIF/DL/csltuconfig/etcd.yml'
dl_redis_file_path = '/DNIF/DL/csltuconfig/redis.yml'
fs_hadoop_path = '/opt/hadoop/etc/hadoop/core-site.xml'



## helper functions :

def read_yaml(file_path):
    with open(file_path, 'r') as file:
        data = yaml.safe_load(file)
    return data

def write_yaml(file_path, data):
    with open(file_path, 'w') as file:
        yaml.safe_dump(data, file)

def update_fs_default_name(file_path, new_value):
    tree = ET.parse(file_path)
    root = tree.getroot()
    for property in root.findall('property'):
        name = property.find('name').text
        if name == 'fs.default.name':
            property.find('value').text = new_value
            break

    #tree.write(file_path, encoding="utf-8", xml_declaration=True)

## Read Change :

Ch_data = read_yaml(config_file)
CoreIP = Ch_data['CO']['Core-IP']
UNET_host_IP = Ch_data['CO']['UNET-host-IP']
#print(f'{CoreIP}   {UNET_host_IP}')

## /DNIF/docker-compose changes

dc_conf = read_yaml(docker_compose_file_path)
envmt_value_co = dc_conf['services']['core']['environment']
envmt_value_dn = dc_conf['services']['datanode-master']['environment']

print('-' * 25 + "docker-compose.yaml" + "-" * 25)
print('== Core  (docker-config)...')

for i, env_var in enumerate(envmt_value_co):
    if env_var.startswith('CORE_IP='):
        envmt_value_co[i]=f'CORE_IP={CoreIP}'
        print(envmt_value_co[i])
        
    elif env_var.startswith('UNET_IP='):
        envmt_value_co[i]=f'UNET_IP={UNET_host_IP}'
        print(envmt_value_co[i])
        
    else:
        print(f"[+] {envmt_value_co[i]} Key NOT FOUND...")

print('== DN-Master (docker-config)...')

for i, env_var in enumerate(envmt_value_dn):
    if env_var.startswith('CORE_IP='):
        envmt_value_dn[i]=f'CORE_IP={CoreIP}'
        print(envmt_value_dn[i])
        
    elif env_var.startswith('UNET_IP='):
        envmt_value_dn[i]=f'UNET_IP={UNET_host_IP}'
        print(envmt_value_dn[i])
        
    else:
        print(f"[+] {envmt_value_dn[i]} Key NOT FOUND...")

print('.' * 50)
print("CORE \n" + json.dumps(envmt_value_co, indent=4))
print("DataNode-Master \n" + json.dumps(envmt_value_dn, indent=4))
#write_yaml(docker_compose_file_path, dc_conf)

##------------- /CO/csltuconfig/etcd.yml --------
print('-' * 25 + "Changing etcd.yml" + '-' * 25)

etc_cnf = read_yaml(etcd_file_path)
etc_cnf['etcd']['host'] = CoreIP
print(f"host = {etc_cnf['etcd']['host']}")
#write_yaml(etcd_file_path, etc_cnf)

##------------ /CO/csltuconfig/redis.yml -----------

print('-' * 25 + "Changing redis.yml" + '-' * 25)

rds_cnf = read_yaml(redis_file_path)
rds_cnf['redis']['host'] = CoreIP
print(f"host = {rds_cnf['redis']['host']}")
#write_yaml(redis_file_path, rds_cnf)

##--------- /DNIF/CO/csltuconfig/SHEEPDOG.yml -----------

print('-' * 25 + "Changing sheepDog.yml" + '-' * 25)

sdog_cnf = read_yaml(sheepDog_file_path)
sdog_cnf['SHEEPDOG']['primary-server']['host'] = CoreIP
print(json.dumps(sdog_cnf['SHEEPDOG']['primary-server'], indent=4))
#write_yaml(sheepDog_file_path,sdog_cnf)

##------------- /DL/csltuconfig/etcd.yml --------
print('-' * 25 + "Changing DL/etcd.yml" + '-' * 25)

dl_etc_cnf = read_yaml(dl_etcd_file_path)
dl_etc_cnf['etcd']['host'] = CoreIP
print(f"host = {dl_etc_cnf['etcd']['host']}")
#write_yaml(dl_etcd_file_path, etc_cnf)

##------------ /DL/csltuconfig/redis.yml -----------

print('-' * 25 + "Changing DL/redis.yml" + '-' * 25)

dl_rds_cnf = read_yaml(dl_redis_file_path)
dl_rds_cnf['redis']['host'] = CoreIP
print(f"host = {dl_rds_cnf['redis']['host']}")
#write_yaml(dl_redis_file_path, rds_cnf)

## ---- /opt/hadoop/etc/hadoop/core-site.xml

print('-' * 25 + "Changing /opt/..../core-site.xml" + '-' * 25)

fs_def_name = f"hdfs://{CoreIP}:9000/"
update_fs_default_name(fs_hadoop_path, fs_def_name)
print(fs_def_name)
print("*" * 20 + "DONE...")


