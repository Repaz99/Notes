import sys
import os
import subprocess
import warnings
sys.path.append('/usr/src/dnif/lc-v9')
from helpers.mongo_helper import find_sorted_result, get_coll_obj
from utils import constants as con
from helpers.nginx_helper import config_cluster_route

## Suppressing urllib warning on execution
warnings.filterwarnings("ignore")

os.environ['WORKDIR'] = '/dnif'
sys.path.append('/usr/src/nm/core-v9')

conn_colln = get_coll_obj(con.COLL_CONN)

ip_map = {'<old_core_ip>': '<private_core_ip>'}
for core_ip, sp_ip in ip_map.items():
    conn_colln.update_one(
             {"coreList": {"$elemMatch": {"coreIP": {"$eq": core_ip}}}},
             {"$set": {"coreList.$.coreIP": sp_ip}},
             upsert=False,
         )
res = find_sorted_result(conn_colln, {}, sort_by='createTS')
cluster_cnt = 1
for i in res:
    # for cluster specific routes
    cluster_id = i['clusterId']
    core_ip = i['coreList'][0]['coreIP']
    print("Configuring routes for ClusterID {}".format(cluster_id))
    config_cluster_route(cluster_id=cluster_id, core_ip=core_ip)
    print("Finished configuring routes")
    if cluster_cnt == 1:
        # for default routes
        cmd = ["sed", "-i", f"s/\:\/\/$core_ip/\:\/\/{core_ip}/g", "/etc/nginx/sites-available/dnif_ui.conf"]
        print(subprocess.run(cmd))
        nginx_cmd = ["nginx", "-s", "reload"]
        print(subprocess.run(nginx_cmd))
