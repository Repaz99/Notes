import json
import ast
import sys
import os
import warnings
import yaml
import tarfile
from datetime import datetime

## Suppressing urllib warning on execution
warnings.filterwarnings("ignore")

#=================== Pre-Check | Arguments =============

if len(sys.argv) < 2 :
    print("[+] Syntex error..... \nUsage: #python3 key_helper.py <[co|dn|ad|compId]> <[get|put]> \n")
    sys.exit(1)

if sys.argv[1] == 'co' or sys.argv[1] == 'dn' or sys.argv[1] == 'ad' or sys.argv[1] == 'compId' :
    run_type = sys.argv[1]
else : 
    print('\033[1;31m[+] Perameter is invalid...\nUse [co|dn|ad|compId]\n\n Syntax: #python3 key_helper.py <[co|dn|ad|compId]> <[get|put]> \033[1;37m\n')
    sys.exit(1)

if sys.argv[2] == 'get' or sys.argv[2] == 'put':
    run_action = sys.argv[2]
else : 
    print('\033[1;31m[+] Perameter is invalid...\nUse [co|dn|ad|compId]\n\n Syntax: #python3 key_helper.py <[co|dn|ad|compId]> <[get|put]> \033[1;37m\n')
    sys.exit(1)



#=================  Setting up environment and import path ================
os.environ['WORKDIR'] = '/dnif'
sys.path.append('/usr/src/nm/core-v9')

from config_loader import etcd_conf
from core_utils.etcd_helper.etcd_helper import ConfigManager
etcd = ConfigManager(host=etcd_conf.ETCD_HOST, port=etcd_conf.ETCD_PORT)

#================== definition Zone =============

def dict_to_json_array(dictionary):
    json_array = [{"key": key, "value": value} for key, value in dictionary.items()]
    return json.dumps(json_array, indent=4)

def backup_tar(fileName, r_type):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_file = f"./{r_type}_backup_{timestamp}.tar.gz"
    with tarfile.open(backup_file, "w:gz") as tar:
        tar.add(fileName, arcname=os.path.basename(fileName))
    print(f"Backup created: {backup_file}")

def fetch_key(run_type):
    if run_type == 'compId' :
        prefix = '/cfg/' + run_type
    else:
        prefix = '/cfg/' + run_type + "/"
    m_entries = etcd.get_prefix(prefix)
    filter_entries = {}
    for entry in m_entries:
        key = entry.key.decode('utf-8')
        value = entry.value.decode('utf-8')
        try:
            b = ast.literal_eval(value)
            jvalue = json.dumps(b)
            res_json = json.loads(jvalue)
        except:
            res_json = value
        filter_entries[key] = res_json

    json_output = dict_to_json_array(filter_entries)
    x_list = json.loads(json_output)
    f_name = "./" + run_type + ".json"
    with open(f_name, 'w') as json_file:
        json.dump(x_list, json_file, indent=4)
    backup_tar(f_name,run_type)

def put_key(run_type):
    if run_type == "dn" :
        with open("./dn.json") as f :
            b = json.load(f)
        for entry in b:
            key = entry['key']
            value = entry['value']
            print(f"writing...\n{key} == {value}\n")
            etcd.put(key,value)
            print("Done...\n")
    elif run_type == "ad":
        with open("./ad.json") as f :
            b = json.load(f)
        for entry in b:
            key = entry['key']
            value = entry['value']
            print(f"writing...\n{key} == {value}\n")
            etcd.put(key,value)
            print("Done...\n")
    elif run_type == "co":
        with open("./co.json") as f :
            b = json.load(f)
        for entry in b:
            key = entry['key']
            value = entry['value']
            print(f"writing...\n{key} == {value}\n")
            etcd.put(key,value)
            print("Done...\n")
    elif run_type == "compId":
        with open("./compId.json") as f :
            b = json.load(f)
        for entry in b:
            key = entry['key']
            value = entry['value']
            print(f"writing...\n{key} == {value}\n")
            etcd.put(key,value)
            print("Done...\n")

    else:
        print("WRONG TYPE Selected...")

if run_action == 'get':
    fetch_key(run_type)
elif run_action == 'put':
    put_key(run_type)
else:
    print("WRONG ACTION (get|put) selected")
